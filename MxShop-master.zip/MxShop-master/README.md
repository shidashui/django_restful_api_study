# MxShop
Django REST framework + vue 打造生鲜超市<br />

## 环境
python: 3.6.4<br /> 
Django: 2.0.2
### MyBlog
我的博客中有对应项目详细教程
[Cnblog](http://www.cnblogs.com/derek1184405959/p/8733194.html)<br /> 
### xadmin下载地址
[点击下载](https://github.com/sshwsfc/xadmin/tree/django2)<br /> 
### 富文本编辑器Ueditor下载地址
[点击下载](https://github.com/twz915/DjangoUeditor3/)<br /> 


