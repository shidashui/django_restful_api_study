

default_app_config = 'goods.apps.GoodsConfig'