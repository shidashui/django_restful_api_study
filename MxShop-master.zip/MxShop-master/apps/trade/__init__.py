

default_app_config = 'trade.apps.TradeConfig'